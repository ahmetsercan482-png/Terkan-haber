# TERKAN PRO HABER & PİYASA LIVE

Bu paket, yüklediğiniz eski HTML'deki sabit/demonstrasyon haber, hava ve piyasa verilerini canlı API mimarisine dönüştürür.

## Ne canlı?
- Haber: TRT Haber resmi RSS akışları; kategori bazında yenilenir.
- Hava: Open-Meteo; seçilen şehir koordinatına göre güncel koşullar ve 7 günlük tahmin.
- Döviz: Twelve Data; USD/TRY, EUR/TRY, GBP/TRY.
- Altın: XAU/USD ve USD/TRY üzerinden gram altın hesaplaması.
- Bitcoin: BTC/USD.
- Piyasa WebSocket: Twelve Data destekliyorsa fiyat akışını alır.
- AI: OpenAI Responses API, sadece OPENAI_API_KEY verilirse.

## Kurulum
1. Node.js 18+ sunucusuna klasörü yükleyin.
2. Terminalde klasöre girin:
   npm install
3. `.env.example` dosyasını `.env` olarak kopyalayın.
4. `TWELVEDATA_API_KEY` değerini ekleyin.
5. İsterseniz `OPENAI_API_KEY` ekleyin.
6. Çalıştırın:
   npm start
7. Tarayıcıdan `http://SUNUCU:3000` adresini açın.

## Önemli
API anahtarlarını `public/index.html` içine koymayın. Sunucu tarafındaki `.env` dosyasında tutun.

## Eğer hosting sadece HTML kabul ediyorsa
Bu paket Node.js backend olmadan tam canlı çalışmaz. Özellikle gerçek zamanlı döviz ve haber RSS erişimi için sunucu gerekir. Node.js/VPS/Render/Railway/Fly.io benzeri bir sunucu kullanın.
