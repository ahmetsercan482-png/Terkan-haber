require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const Parser = require('rss-parser');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });
const parser = new Parser({ timeout: 10000 });

app.use(cors());
app.use(express.json({limit:'64kb'}));
app.use(express.static(path.join(__dirname, 'public')));

const PORT = Number(process.env.PORT || 3000);
const TD_KEY = process.env.TWELVEDATA_API_KEY || '';
const OPENAI_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-6-luna';

const RSS = {
  sonDakika: ['https://www.trthaber.com/sondakika_articles.rss'],
  ekonomi: ['https://www.trthaber.com/ekonomi_articles.rss'],
  teknoloji: ['https://www.trthaber.com/bilim_teknoloji_articles.rss'],
  gundem: ['https://www.trthaber.com/gundem_articles.rss'],
  yerel: ['https://www.trthaber.com/turkiye_articles.rss']
};

const newsCache = new Map();
let marketCache = {updatedAt:null, markets:[]};
let providerWS = null;
let providerWSRetry = null;

function clean(s){ return String(s||'').replace(/<[^>]*>/g,'').trim(); }
function imageFrom(item){
  if(item.enclosure && item.enclosure.url) return item.enclosure.url;
  const html=item.content||item['content:encoded']||'';
  const m=html.match(/<img[^>]+src=["']([^"']+)["']/i);
  return m ? m[1] : null;
}

async function fetchNews(category){
  const urls=RSS[category] || RSS.sonDakika;
  const all=[];
  for(const url of urls){
    try{
      const feed=await parser.parseURL(url);
      for(const item of (feed.items||[]).slice(0,40)){
        all.push({
          source: feed.title || 'TRT Haber',
          title: clean(item.title),
          description: clean(item.contentSnippet || item.summary || item.content || ''),
          url: item.link || '',
          date: item.isoDate || item.pubDate || new Date().toISOString(),
          image: imageFrom(item)
        });
      }
    }catch(err){ console.error('RSS error',url,err.message); }
  }
  all.sort((a,b)=>new Date(b.date)-new Date(a.date));
  const unique=[]; const seen=new Set();
  for(const n of all){ if(!seen.has(n.url||n.title)){seen.add(n.url||n.title);unique.push(n);} }
  newsCache.set(category,{updatedAt:new Date().toISOString(),news:unique.slice(0,50)});
  return newsCache.get(category);
}

app.get('/api/news', async (req,res)=>{
  const category=String(req.query.category||'sonDakika');
  const cached=newsCache.get(category);
  if(cached && Date.now()-new Date(cached.updatedAt).getTime()<25000) return res.json(cached);
  try{return res.json(await fetchNews(category));}
  catch(e){return res.status(502).json({error:'Haber kaynağına ulaşılamadı'});}
});

app.get('/api/weather', async (req,res)=>{
  try{
    const lat=Number(req.query.lat), lon=Number(req.query.lon);
    if(!Number.isFinite(lat)||!Number.isFinite(lon)) return res.status(400).json({error:'Geçersiz koordinat'});
    const url='https://api.open-meteo.com/v1/forecast';
    const r=await axios.get(url,{params:{latitude:lat,longitude:lon,timezone:'auto',forecast_days:7,current:'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,is_day',hourly:'temperature_2m,relative_humidity_2m,precipitation_probability,weather_code,wind_speed_10m',forecast_days:7},timeout:10000});
    res.json({updatedAt:new Date().toISOString(),weather:r.data});
  }catch(e){res.status(502).json({error:'Hava durumu alınamadı'});}
});

async function tdQuote(symbol){
  if(!TD_KEY) throw new Error('TWELVEDATA_API_KEY yok');
  const r=await axios.get('https://api.twelvedata.com/quote',{params:{symbol,apikey:TD_KEY},timeout:10000});
  if(r.data.status==='error') throw new Error(r.data.message||'Twelve Data error');
  return r.data;
}

async function refreshMarkets(){
  if(!TD_KEY) throw new Error('TWELVEDATA_API_KEY yok');
  const symbols=['USD/TRY','EUR/TRY','GBP/TRY','XAU/USD','BTC/USD'];
  const results=await Promise.all(symbols.map(async s=>{try{return [s,await tdQuote(s)];}catch(e){return [s,{error:e.message}];}}));
  const map=Object.fromEntries(results);
  const out=[];
  function add(name,symbol,dec=2){
    const q=map[symbol]; if(!q||q.error||q.close==null) return;
    out.push({name,value:Number(q.close).toLocaleString('tr-TR',{minimumFractionDigits:dec,maximumFractionDigits:dec})+' TL',change:Number(q.percent_change||0),sub:'Twelve Data • piyasa verisi'});
  }
  add('ABD Doları (USD/TRY)','USD/TRY',4);
  add('Euro (EUR/TRY)','EUR/TRY',4);
  add('İngiliz Sterlini (GBP/TRY)','GBP/TRY',4);
  const usdtry=Number(map['USD/TRY']?.close), xauusd=Number(map['XAU/USD']?.close);
  if(Number.isFinite(usdtry)&&Number.isFinite(xauusd)){
    const gram=xauusd*usdtry/31.1034768;
    const ch=Number(map['XAU/USD']?.percent_change||0)+Number(map['USD/TRY']?.percent_change||0);
    out.push({name:'Gram Altın (XAU/TRY)',value:gram.toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2})+' TL',change:ch,sub:'XAU/USD × USD/TRY • hesaplanan'});
  }
  if(map['XAU/USD']?.close) out.push({name:'Altın (XAU/USD)','value':'$'+Number(map['XAU/USD'].close).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}),change:Number(map['XAU/USD'].percent_change||0),sub:'Ons altın'});
  if(map['BTC/USD']?.close) out.push({name:'Bitcoin (BTC/USD)','value':'$'+Number(map['BTC/USD'].close).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}),change:Number(map['BTC/USD'].percent_change||0),sub:'Kripto piyasa verisi'});
  marketCache={updatedAt:new Date().toISOString(),markets:out};
  broadcastMarkets();
  return marketCache;
}

app.get('/api/markets', async (req,res)=>{
  try{
    if(!marketCache.updatedAt || Date.now()-new Date(marketCache.updatedAt).getTime()>20000) await refreshMarkets();
    res.json(marketCache);
  }catch(e){res.status(503).json({error:e.message,markets:[]});}
});

async function askAI(question){
  if(!OPENAI_KEY) throw new Error('OPENAI_API_KEY yok');
  const r=await axios.post('https://api.openai.com/v1/responses',{
    model:OPENAI_MODEL,
    input:[{role:'system',content:'Terkan Haber AI asistanısın. Türkçe yanıt ver. Güncel piyasa/haber bilgisini kendin uydurma; uygulamadaki canlı veriler için kullanıcıyı uygulamanın güncel kartlarına yönlendir.'},{role:'user',content:question}]
  },{headers:{Authorization:`Bearer ${OPENAI_KEY}`,'Content-Type':'application/json'},timeout:30000});
  return r.data.output_text || 'Yanıt alınamadı.';
}
app.post('/api/ai',async(req,res)=>{
  try{ if(typeof req.body.question!=='string'||!req.body.question.trim()) return res.status(400).json({error:'Soru gerekli'}); res.json({answer:await askAI(req.body.question)}); }
  catch(e){res.status(503).json({error:e.message});}
});

function broadcastMarkets(){
  const msg=JSON.stringify({type:'markets',...marketCache});
  for(const client of wss.clients) if(client.readyState===WebSocket.OPEN) client.send(msg);
}
wss.on('connection',ws=>{ if(marketCache.updatedAt) ws.send(JSON.stringify({type:'markets',...marketCache})); });

function connectProviderWS(){
  if(!TD_KEY) return;
  try{
    providerWS=new WebSocket(`wss://ws.twelvedata.com/v1/quotes/price?apikey=${encodeURIComponent(TD_KEY)}`);
    providerWS.on('open',()=>providerWS.send(JSON.stringify({action:'subscribe',params:{symbols:'USD/TRY,EUR/TRY,GBP/TRY,XAU/USD,BTC/USD'}})));
    providerWS.on('message',buf=>{
      try{
        const d=JSON.parse(buf.toString());
        if(d.event==='price' && d.symbol && d.price){
          // Provider akışını kısa aralıkta cache'leyip REST verisiyle tamamlıyoruz.
          refreshMarkets().catch(()=>{});
        }
      }catch(_){ }
    });
    providerWS.on('close',()=>{clearTimeout(providerWSRetry);providerWSRetry=setTimeout(connectProviderWS,5000);});
    providerWS.on('error',()=>{});
  }catch(e){providerWSRetry=setTimeout(connectProviderWS,5000);}
}

setInterval(()=>{ if(TD_KEY) refreshMarkets().catch(()=>{}); }, 30000);
setInterval(()=>{ for(const cat of Object.keys(RSS)) fetchNews(cat).catch(()=>{}); }, 60000);

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
server.listen(PORT,()=>{
  console.log(`Terkan Pro Live: http://localhost:${PORT}`);
  Object.keys(RSS).forEach(c=>fetchNews(c).catch(()=>{}));
  if(TD_KEY){refreshMarkets().catch(console.error);connectProviderWS();}
});
